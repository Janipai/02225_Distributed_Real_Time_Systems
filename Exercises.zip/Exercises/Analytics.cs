using System.Text.Json;
using _02225.Entities;

/*
TODO: Move into separate files
- BDRMath
- Results
- Analyser
*/
namespace _02225;

    /*
    1. Pure math helpers 
    – dbf, 
    - sbf, 
    - Half‑Half
    */
    internal static class BdrMath
    {
        /* dbf for EDF – Eq (2)/(3)  (implicit deadline = period - given in the project description) */
        public static long DbfEdf(IEnumerable<ProjectTask> tasks, long t)
        {
            /*
             * Project assumption: implicit‑deadline periodic tasks, i.e. Di = Ti.
             * Therefore dbfEDF(W,t) = Σ ⌊ t / Ti ⌋ · Ci   (Eq. 2 simplified).
             */
            long demand = 0;
            foreach (var τ in tasks)
            {
                long jobs = t / τ.Period;      // ⌊ t / T ⌋
                demand += jobs * τ.Wcet;
            }
            return demand;
        }

        /* dbf for RM/FPS – Eq (4) */
        public static long DbfRm(ProjectTask target, IEnumerable<ProjectTask> higher, long t)
        {
            long sum = target.Wcet;
            foreach (var τ in higher)
            {
                long jobs = (long)Math.Ceiling((double)t / τ.Period);
                sum += jobs * τ.Wcet;
            }
            return sum;
        }

        /* Supply‑bound function for a BDR resource (α, Δ) – Eq (6) */
        public static long SbfBdr(double alpha, long delta, long t)
        {
            if (t < delta) return 0;
            return (long)Math.Floor(alpha * (t - delta));
        }

        /* Half‑Half theorem – convert (α,Δ) to a periodic supply task (C,T) */
        public static (long C, long T) ToSupplyTask(double alpha, long delta)
        {
            double C = alpha * delta / (2 * (1 - alpha));
            double T = delta / (2.0 * (1 - alpha));
            return ((long)Math.Ceiling(C), (long)Math.Ceiling(T));
        }
    }

    /*
    2. Result records (immutable) – used in JSON & console reporting
    */
    public record Violation(long Interval, long Demand, long Supply);
    
    public record ComponentResult(
        string                       Id,
        string                       Scheduler,
        double                       Alpha,
        long                         Delta,
        bool                         Pass,
        List<ComponentResult>        Children,
        List<Violation>?             Violations);

    public record CoreResult(int CoreId, double SpeedFactor, bool Pass, ComponentResult Root);

    /*
    Analyzer – orchestrates bottom‑up interface synthesis & top‑down checks
    */
    public class Analyzer
    {
        public void Run(CompleteCase cc)
        {
            Console.WriteLine($"Simulation Time: {cc.GetSimulationTime()}");

            // Flat list of all components and grouping of tasks by component
            var comps = cc.GetBudget().GetComponents();
            var tasksByComp = cc.GetTaskList().GetTasks()
                .GroupBy(t => t.ComponentId)
                .ToDictionary(g => g.Key, g => g.ToList());

            // For each core, build a synthetic root node containing all its components as children
            foreach (var core in cc.GetArchitecture().GetCores())
            {
                // Synthetic root uses core's ID and scheduler
                var root = new ComponentNode(core.CoreId, core.Scheduler);

                // Each Component c assigned to this core becomes a leaf
                foreach (var comp in comps.Where(c => c.Core?.CoreId == core.CoreId))
                {
                    var leaf = new ComponentNode(comp.ComponentId, comp.Scheduler);
                    
                    // add this component's tasks into the leaf
                    if (tasksByComp.TryGetValue(comp.ComponentId, out var tl))
                        leaf.Tasks.AddRange(tl);
                    root.Children.Add(leaf);
                }

                // Bottom-up: synthesize the minimal α for increasing Δ
                var (alpha, delta) = SynthesizeInterface(root, core.Speed);
                Console.WriteLine($"Core {core.CoreId}: α={alpha:F3}, Δ={delta}");
            }
        }


        private (double alpha, long delta) SynthesizeInterface(ComponentNode node, double speed)
        {
            if (!node.Children.Any() && !node.Tasks.Any())
                return (0, 0);

            var periods = node.Tasks
                              .Select(t => t.Period)
                              .DefaultIfEmpty(1)
                              .ToArray();
            long gcd = periods.Aggregate(BdrMath.Gcd);
            long lcm = periods.Aggregate(BdrMath.Lcm);

            double bestAlpha = 1.0;
            long bestDelta = lcm;

            for (long delta = gcd; delta <= lcm; delta += gcd)
            {
                double alpha = FindMinAlpha(node, delta, speed);
                if (alpha < bestAlpha)
                {
                    bestAlpha = alpha;
                    bestDelta = delta;
                }
            }
            return (bestAlpha, bestDelta);
        }

        private double FindMinAlpha(ComponentNode node, long delta, double speed)
        {
            double lo = 0.0, hi = 1.0, eps = 1e-4;
            while (hi - lo > eps)
            {
                double mid = (hi + lo) / 2;
                if (Dominates(node, mid, delta, speed)) hi = mid; else lo = mid;
            }
            return hi;
        }

        private bool Dominates(ComponentNode node, double alpha, long delta, double speed)
        {
            long baseStep = node.Tasks.Any() ? node.Tasks.Min(t => t.Period) : delta;
            long lcm = node.Tasks.Any()
                       ? node.Tasks.Select(t => t.Period).Aggregate(BdrMath.Lcm)
                       : delta * 4;

            bool isEdf = node.Scheduler == "EDF";
            var hpSorted = node.Tasks.OrderBy(t => t.Period).ToList();

            for (long t = 0; t <= lcm; t += baseStep)
            {
                long demand = 0;
                if (isEdf)
                {
                    demand = BdrMath.DbfEdf(node.Tasks, t);
                }
                else
                {
                    for (int i = 0; i < hpSorted.Count; i++)
                    {
                        var tau = hpSorted[i];
                        var higher = hpSorted.Take(i);
                        long d = BdrMath.DbfRm(tau, higher, t);
                        demand = Math.Max(demand, d);
                    }
                }
                long supply = BdrMath.SbfBdr(alpha, delta, t);
                if (demand > supply) return false;
            }
            return true;
        }
    }

    internal class ComponentNode
    {
        public string Id { get; }
        public string Scheduler { get; }
        public List<ComponentNode> Children { get; } = new();
        public List<ProjectTask> Tasks { get; } = new();

        public ComponentNode(string id, string scheduler)
        {
            Id = id;
            Scheduler = scheduler;
        }
    }


