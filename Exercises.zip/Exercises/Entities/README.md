CompleteCase
    ├─ Architecture : List<Core>           core‑level hardware info
    ├─ Budget       : List<Component>      component hierarchy
    └─ Tasks        : List<ProjectTask>    flat task list